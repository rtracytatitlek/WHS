
# SQL Server driver for Drupal 7

See http://drupal.org/project/sqlsrv for installation instructions.
