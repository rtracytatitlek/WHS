INSTALL
==========

1. Extract module into /sites/all/modules folder.
2. Enable "Path Breadcrumbs" and "Path Breadcrumbs UI" on /admin/modules page.


USAGE
==========

Go to /admin/structure/path-breadcrumbs and create new breadcrumb.

@TODO: provide better documentation and show demo.


CREDITS
=========

Module was developed by Maslouski Yauheni (http://drupalace.ru).
Module development was not sponsored by anyone. It was created for the love of Drupal.
