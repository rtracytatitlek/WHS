
Field reference README

CONTENTS OF THIS FILE
----------------------

  * Introduction
  * Installation
  * Usage


INTRODUCTION
------------
Defines a field type for referencing one field from another.

Project page: http://drupal.org/project/field_reference.


INSTALLATION
------------
Install and enable the Field reference module.
For detailed instructions on installing contributed modules see:
http://drupal.org/documentation/install/modules-themes/modules-7


USAGE
-----
Field reference fields will now be available in the Field UI.
For detailed instructions on using the Field UI see:
http://drupal.org/documentation/modules/field-ui