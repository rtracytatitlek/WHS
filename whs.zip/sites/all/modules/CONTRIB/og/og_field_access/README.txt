DESCRIPTION
-----------
The "Organic groups field access" module lets you define which fields are
accessible by group members and non-members. For each field that is in a group
or a group content you can decide who can view the field and who can edit it.

USAGE
-----
1. Enable Organic Groups Field Access at admin/modules
2. Go to admin/config/group/permissions and define the access permissions
